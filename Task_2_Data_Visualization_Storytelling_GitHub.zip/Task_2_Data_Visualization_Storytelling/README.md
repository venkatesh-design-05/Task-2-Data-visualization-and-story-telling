# Data Analyst Internship — Task 2: Data Visualization and Storytelling

## Objective
Create visualizations that convey a compelling story using sales data.

## Dataset
This repository uses `sales_data.csv`, a reproducible sample sales dataset created for this task. The task instructions allow **Superstore.csv or any sales data of your choice**.

## Deliverables
- `Task_2_Visual_Report.pdf` — final visual report
- `sales_data.csv` — dataset used
- `charts/` — individual chart images
- `README.md` — project documentation

## Visualizations
1. Monthly Sales Trend — line chart
2. Sales by Category — bar chart
3. Sales by Region — horizontal bar chart
4. Profit by Category — bar chart

## Key Business Insights
- Top sales category: **Technology** (297,160)
- Top sales region: **East** (154,747)
- Peak sales month: **December 2025** (62,107)
- Top profit category: **Technology** (104,817)
- Total sales: **483,694**
- Total profit: **162,246**

## Interview Questions

### 1. What is the importance of data visualization?
Data visualization converts raw data into charts and graphs that make patterns, trends, comparisons, and outliers easier to understand and communicate.

### 2. When do you use a pie chart vs bar chart?
A pie chart can be used for a small number of parts-of-a-whole comparisons. A bar chart is generally more suitable when comparing several categories or when precise comparison is important.

### 3. How do you make visualizations more engaging?
Use an appropriate chart type, clear titles, useful labels, limited colors, meaningful annotations, and business context. Highlight the key takeaway rather than adding decoration.

### 4. What is data storytelling?
Data storytelling combines data, visualizations, and narrative to explain what happened, why it matters, and what action or question should follow.

### 5. How do you avoid misleading visualizations?
Use accurate scales, avoid distorted axes, provide context, label metrics clearly, avoid cherry-picking, and disclose relevant limitations in the dataset.

### 6. What are best practices in dashboard design?
Keep the layout simple, establish a clear visual hierarchy, use consistent formatting, avoid clutter, provide filters only when useful, label charts clearly, and place the most important KPIs where they are easy to find.

### 7. What tools have you used for visualization?
For this task, the internship brief specifies **Tableau / Power BI** as the visualization tools. This submission is a visual report prepared from the task's sales-data requirements; it does not claim that the PDF itself was generated inside Tableau or Power BI.

## Submission
Upload this entire folder to a new GitHub repository for Task 2.
